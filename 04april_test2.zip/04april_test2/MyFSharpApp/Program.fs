﻿// For more information see https://aka.ms/fsharp-console-apps
printfn "name jaskaran kaur  student id 22049580"

// Define discriminated union for movie genres
type Genre =
    | Horror
    | Drama
    | Thriller
    | Comedy
    | Fantasy
    | Sport

// Define record type for Director
type Director = {
    Name: string
    Movies: int
}

// Define record type for Movie
type Movie = {
    Name: string
    RunLength: int
    Genre: Genre
    Director: Director
    IMDBRating: float
}

// Create movie instances
let movies =
    [
        { Name = "CODA"; RunLength = 111; Genre = Drama; Director = { Name = "Sian Heder"; Movies = 9 }; IMDBRating = 8.1 }
        { Name = "belfast"; RunLength = 98; Genre = Comedy; Director = { Name = "Kenneth Branagh"; Movies = 23 }; IMDBRating = 7.3 }
        { Name = "don't look up"; RunLength = 138; Genre = Comedy; Director = { Name = "Adam McKay"; Movies = 27 }; IMDBRating = 7.2 }
        { Name = "drive my car"; RunLength = 179; Genre = Drama; Director = { Name = "Ryusuke Hamaguchi"; Movies = 16 }; IMDBRating = 7.6 }
        { Name = "dune"; RunLength = 155; Genre = Fantasy; Director = { Name = "Denis Villeneuve"; Movies = 24 }; IMDBRating = 8.1 }
        { Name = "king Richard"; RunLength = 144; Genre = Sport; Director = { Name = "Reinaldo Marcus Green"; Movies = 15 }; IMDBRating = 7.5 }
        { Name = "licorice pizza"; RunLength = 133; Genre = Comedy; Director = { Name = "Paul Thomas Anderson"; Movies = 49 }; IMDBRating = 7.4 }
        { Name = "nightmare"; RunLength = 150; Genre = Thriller; Director = { Name = "Guillermo Del Toro"; Movies = 22 }; IMDBRating = 7.1 }
    ]

// Identify probable Oscar winners
let probableOscarWinners =
    movies
    |> List.filter (fun movie -> movie.IMDBRating > 7.4)

// Function to convert run length from minutes to "Xh Ymin" format
let formatRunLength runLength =
    let hours = runLength / 60
    let minutes = runLength % 60
    sprintf "%dh %dmin" hours minutes

// Convert run length to hours format and arrange display
let convertedRunLengths =
    movies
    |> List.map (fun movie ->
        let formattedRunLength = formatRunLength movie.RunLength
        sprintf "Name: %s, Genre: %A, IMDB Rating: %.1f, Director: %s, Run Length: %s" movie.Name movie.Genre movie.IMDBRating movie.Director.Name formattedRunLength)

// Print results
printfn "Probable Oscar Winners:"
probableOscarWinners |> List.iter (fun movie -> printfn "- %s" movie.Name)
printfn "\nMovies with Details:"
convertedRunLengths |> List.iter (printfn "- %s")
